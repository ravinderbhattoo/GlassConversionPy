from GlassConversionPy.convert import M2W, W2M

if __name__ == "__main__":
    print("M2W(x) convert mol% to weight%.")
    print("W2M(x) convert weight% to mol%.")
    print("where x can be: ")
    print("x = {'CaO': 50, 'MgO: 50'}, ")
    print("x = pandas.DataFarme({'CaO': 50, 'MgO: 50'}) or ")
    print("x = 50CaO-50MgO .")
